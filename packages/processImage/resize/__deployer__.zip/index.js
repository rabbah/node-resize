const { resizeImage } = require('./resizeImage');
const { readMultipart } = require('./readMultipart');
const { spacesUpload } = require('./spacesUpload');

async function main(args) {
  console.log(args);
  try {
    const parts = await readMultipart(args);
    const image = await resizeImage(parts.file);
    // const image = await resizeImage(args);
    const data = await spacesUpload(image);
    return {
      body: data
    }
  } catch (error) {
    return {
      body: {
        error: error
      }
    }
  }
}

exports.main = main;
// main('sammy.png')